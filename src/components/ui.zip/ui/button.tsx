import * as React from "react"
import { Slot } from "@radix-ui/react-slot"
import { cva, type VariantProps } from "class-variance-authority"

import { cn } from "@/lib/utils"

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground hover:bg-primary-hover border-4 border-black shadow-comic hover:shadow-comic-lg transform hover:-translate-y-1 transition-all duration-200 font-comic font-bold",
        destructive:
          "bg-destructive text-destructive-foreground hover:bg-destructive/90 border-4 border-black shadow-comic",
        outline:
          "border-4 border-black bg-background hover:bg-secondary hover:text-secondary-foreground shadow-comic hover:shadow-comic-lg transform hover:-translate-y-1 transition-all duration-200 font-comic",
        secondary:
          "bg-secondary text-secondary-foreground hover:bg-secondary-hover border-4 border-black shadow-comic hover:shadow-comic-lg transform hover:-translate-y-1 transition-all duration-200 font-comic font-bold",
        ghost: "hover:bg-accent hover:text-accent-foreground font-comic",
        link: "text-primary underline-offset-4 hover:underline font-comic",
        hero: "bg-gradient-hero text-accent-foreground border-4 border-black shadow-comic-lg hover:shadow-glow transform hover:-translate-y-2 hover:scale-105 transition-all duration-300 font-comic text-xl font-bold",
        cta: "bg-accent text-accent-foreground hover:bg-accent/90 border-4 border-black shadow-comic-lg animate-bounce-gentle font-comic font-bold text-lg",
      },
      size: {
        default: "h-12 px-6 py-3 text-base",
        sm: "h-10 rounded-md px-4 text-sm",
        lg: "h-14 rounded-md px-10 text-lg",
        xl: "h-16 rounded-md px-12 text-xl",
        icon: "h-12 w-12",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
)

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button"
    return (
      <Comp
        className={cn(buttonVariants({ variant, size, className }))}
        ref={ref}
        {...props}
      />
    )
  }
)
Button.displayName = "Button"

export { Button, buttonVariants }
